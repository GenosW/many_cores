# Exercise 2

## Task 1: Basic CUDA

Output for (a):

    (1) Elapsed: 0.056115
    (2) Elapsed: 0.00013
    (3) Elapsed: 0.000137
    (4) Elapsed: 0.000152
    (5) Elapsed: 0.000139
    (6) Elapsed: 0.000133
    (7) Elapsed: 0.000137
    (8) Elapsed: 0.000166
    (9) Elapsed: 0.000133
    (10) Elapsed: 0.000128

    Results after 10 tests:
    Total runtime: 0.05737
    Average runtime; 0.005737
    Maximum runtime: 0.056115
    Minimum runtime: 0.000128

Output for (b):

