#!fish

wget -P data/buffer -i urls.txt
mv data/buffer/* data/.
